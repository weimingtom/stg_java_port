/*
 * Background.js
 * Represents the main playing canvas.
 * This class is not really a sprite so it doesn't extend it.
 * Lots of methods and properties are the same though
 * 
 * Copyright (c) Sako 2010 - zomgsako@gmail.com
 * Freely redistributable and editable.
*/

function Background()
{
	this.w = canv.width; // screen width
	this.h = canv.height; // screen height
	
	this.y = 0; // background scrolling position
	
	this.padding = 10; // internal padding where player cannot step
}

Background.prototype.move = function()
{
	// scroll lines to the bottom a bit
	this.y += 4;
}
	
Background.prototype.draw = function()
{
	// draw bg lines
	ctx.lineWidth = 1;
	ctx.strokeStyle = 'rgba(0,0,192,255)';
		
	for (var i = 0; i < 8; i++)
	{
		ctx.beginPath();
		ctx.moveTo(0, (this.y + (i*50))%this.h);
		ctx.lineTo(this.w, (this.y + (i*50))%this.h);
		ctx.closePath();
		ctx.stroke();
	}
}
	
Background.prototype.clear = function()
{
	// fill background
	ctx.fillStyle = 'rgba(0,0,128,255)';
	ctx.fillRect(0, 0, this.w, this.h);
}
	
Background.prototype.work = function()
{
	this.clear();
	this.move();
	this.draw();
}
