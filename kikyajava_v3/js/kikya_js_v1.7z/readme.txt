canv:画布
	.width
	.height
	
sh_p:控制Player是否执行-shoot

---------------------------------

Sprite:
	.w:
	.h:
	.image:
	.color:默认为黑色
	.dead:0/1,是否应该移除
	.movements:Movement[]
	.movement:Movement
	-addMovement:
	-addRelativeMovement:
	-addLoopingMovement:
	-move:逻辑处理
		movements为空，则dead为1
		movement为空，则取movements[0]
		movement完成，则移除之
		如果movement是loop，则重新放回队列。
		如果movement为relative，则在消失前使用当前属性值创建新的Movement。
	-check:判断this.dead为1
	-draw:绘画图片或填充矩形颜色
	-area:矩形位置{x1, y1, x2, y2}
	-work:生命周期move->check->draw
	::Enemy
	::EnemyBullet
	::Explosion
	::Player
	::PlayerBullet
	::Powerup
	::Text

---------------------------------

Background:背景，非Sprite子类
	.w:宽度，等于画布宽度
	.h:高度，等于画布宽度
	.y:滚动位置
	.padding:限制边界区域宽度
	-move:向下滚动
	-draw:绘画（绘画n个矩形）

Explosion<Sprite:图片为img_ex

Text<Sprite
	.text:文本
	.size:文本大小
	.align:对齐
	-draw:覆盖

Powerup<Sprite
	.type:p力量s分数
	-check:覆盖
	
EnemyBullet<Sprite
	.delay:子弹生成延迟
	.homing
	-check:
	-area:覆盖，防止碰撞不到
	
PlayerBullet<Sprite
	.delay:生成延时
	-check:覆盖
	-area:覆盖，防止碰撞不到

---------------------------------

Player<Sprite
	.power:
	-move:覆盖
	-shoot:
	-work:覆盖，在超类方法后判断是否执行-shoot

Enemy<Sprite
	.hit
	.life
	.level
	.spellcard
	.delay:子弹生成延迟
	-check
	-shoot
	-drop
	-work:覆盖，在超类work后执行-shoot

---------------------------------

SpellCard:


Movement:
	

Level:






	
	
	
	
	
